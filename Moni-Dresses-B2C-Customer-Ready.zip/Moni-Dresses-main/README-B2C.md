# Moni Dresses — B2C Customer Website

This repository is the customer-facing B2C website.

## Scope
- Customer product browsing
- Product search/filtering
- Cart and wishlist
- Customer account/authentication foundation
- B2C checkout/order foundation
- Dynamic product/content consumption from the central backend
- Admin-controlled B2C feature flags
- No admin/branch management UI

## Architecture
The B2C site is a consumer client. Product, pricing, inventory availability,
promotions, B2C/B2B visibility, branch rules, and permissions are controlled
by the central Admin/Backend system.

Never put Razorpay secret keys, Shiprocket credentials, database admin keys,
or service-account credentials in this repository.

## Deployment
Deploy this repository as the B2C frontend on its own Vercel project/domain.
Configure public Firebase/web configuration through environment variables as
appropriate for the chosen backend architecture.

## Important
Server-side order validation, Razorpay payment verification, inventory
reservation, and Shiprocket operations must be handled by the backend/Admin
services—not by browser JavaScript.
